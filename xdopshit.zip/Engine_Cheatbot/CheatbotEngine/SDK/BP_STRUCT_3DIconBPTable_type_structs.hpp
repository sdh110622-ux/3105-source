#pragma once

#ifndef _MSC_VER
#ifdef __cplusplus
#define __forceinline inline
#else
#define __forceinline
#endif
#endif

// PUBG (4.3.0) Created by @JokerRepo and for pattern @enen
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_3DIconBPTable_type.BP_STRUCT_3DIconBPTable_type
// 0x0028
struct FBP_STRUCT_3DIconBPTable_type
{
	struct FString                                     CName_0_197F95006C7D41D02E19833803105905;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_6249C74062AE6BD53F17F69101F33054;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Path_2_064E67406FC200F32023304A0331E958;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

