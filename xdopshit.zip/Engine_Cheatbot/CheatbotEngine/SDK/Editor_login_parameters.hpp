#pragma once

#ifndef _MSC_VER
#ifdef __cplusplus
#define __forceinline inline
#else
#define __forceinline
#endif
#endif

// PUBG (4.3.0) Created by @JokerRepo and for pattern @enen
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Editor_login.Editor_login_C.SetFpsByIndex
struct AEditor_login_C_SetFpsByIndex_Params
{
	int                                                idx;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Editor_login.Editor_login_C.InpActEvt_Android_Back_K2Node_InputKeyEvent_12
struct AEditor_login_C_InpActEvt_Android_Back_K2Node_InputKeyEvent_12_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_E_K2Node_InputKeyEvent_11
struct AEditor_login_C_InpActEvt_E_K2Node_InputKeyEvent_11_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_10
struct AEditor_login_C_InpActEvt_BackSpace_K2Node_InputKeyEvent_10_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_B_K2Node_InputKeyEvent_9
struct AEditor_login_C_InpActEvt_B_K2Node_InputKeyEvent_9_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_G_K2Node_InputKeyEvent_8
struct AEditor_login_C_InpActEvt_G_K2Node_InputKeyEvent_8_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.InpActEvt_N_K2Node_InputKeyEvent_7
struct AEditor_login_C_InpActEvt_N_K2Node_InputKeyEvent_7_Params
{
	struct FKey                                        Key;                                                      // (BlueprintVisible, BlueprintReadOnly, Parm)
};

// Function Editor_login.Editor_login_C.ReceiveBeginPlay
struct AEditor_login_C_ReceiveBeginPlay_Params
{
};

// Function Editor_login.Editor_login_C.ExecuteUbergraph_Editor_login
struct AEditor_login_C_ExecuteUbergraph_Editor_login_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

