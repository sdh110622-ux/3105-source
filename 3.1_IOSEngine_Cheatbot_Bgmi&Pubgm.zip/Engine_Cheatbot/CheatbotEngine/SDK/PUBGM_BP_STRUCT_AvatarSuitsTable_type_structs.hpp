#pragma once

// PUBG MOBILE (3.1.0) SDKGenerate by @CheatBot_Owner || 𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖 -: @CheatBot_Tele
namespace CHEATBOT
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_AvatarSuitsTable_type.BP_STRUCT_AvatarSuitsTable_type
// 0x0028
struct FBP_STRUCT_AvatarSuitsTable_type
{
	struct FString                                     FemaleSuits_0_5E12F5C00D5F71393EDCFF620F8ED0B3;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_1_644CE440325AB977296AC86003848904;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     MaleSuits_2_5E52230026563E4833623FFF0E279B13;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

